clc
clear
close all
load('data1.mat')
load('F2.mat')
[ID X Y]=textread('F2.txt','%f%f%f');
t=[X,Y];

% Demonstrate difference spectral similarity measurements
[h, w, p] = size(M);
target=sig1;
figure; plot(target); grid on; title('Target Signature');

M = hyperConvert2d(M);
  
% RX Anomly Detector
r = hyperRxDetector(M);
r = hyperConvert3d(r.', h, w, 1);
figure; imagesc(r); title('RX Detector Results'); axis image;colorbar;

% Constrained Energy Minimization (CEM)
rCEM = hyperCem(M, target);
rCEM2 = hyperConvert3d(rCEM, h, w, 1);
figure; imagesc(abs(rCEM2)); title('CEM Detector Results'); axis image;colorbar;    

% Adaptive Cosine Estimator (ACE)
rACE = hyperAce(M, target);
rACE2 = hyperConvert3d(rACE, h, w, 1);
figure; imagesc(rACE2); title('ACE Detector Results'); axis image;colorbar;   

% Signed Adaptive Cosine Estimator (S-ACE)
rSACE = hyperSignedAce(M, target);
rSACE2 = hyperConvert3d(rSACE, h, w, 1);
figure; imagesc(rSACE2); title('Signed ACE Detector Results'); axis image;colorbar; 

% Matched Filter
rMF = hyperMatchedFilter(M, target);
rMF2 = hyperConvert3d(rMF, h, w, 1);
figure; imagesc(rMF2); title('MF Detector Results'); axis image;colorbar; 

% Generalized Likehood Ratio Test (GLRT) detector
rGLRT = hyperGlrt(M, target);
rGLRT2 = hyperConvert3d(rGLRT, h, w, 1);
figure; imagesc(rGLRT2); title('GLRT Detector Results'); axis image;colorbar;


% Estimate background endmembers
[q] = hyperHfcVd(M,10^-8)
U = hyperAtgp(M, q);

% Adaptive Matched Subspace Detector (AMSD)
rAMSD = hyperAmsd(M, U, target);
rAMSD2 = hyperConvert3d(rAMSD, h, w, 1);
figure; imagesc(abs(rAMSD2)); title('AMSD Detector Results'); axis image;colorbar;
figure; mesh(rAMSD2); title('AMSD Detector Results');

% Orthogonal Subspace Projection (OSP)
rOSP = hyperOsp(M, U, target);
rOSP2 = hyperConvert3d(rOSP, h, w, 1);
figure; imagesc(abs(rOSP2)); title('OSP Detector Results'); axis image;colorbar;   

% Threshold
[counts,x] = imhist(rOSP,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rOSP,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('OSP Detector Results');

%ROC
[AUC1,FPR1,TPR1]=hyperRoc(rCEM,t);
figure;plot(FPR1,TPR1,'^-')
hold on

[AUC2,FPR2,TPR2]=hyperRoc(rACE,t);
plot(FPR2,TPR2,'*-')

hold on
[AUC3,FPR3,TPR3]=hyperRoc(rSACE,t);
plot(FPR3,TPR3,'o-')

[AUC4,FPR4,TPR4]=hyperRoc(rMF,t);
plot(FPR4,TPR4,'v-')

[AUC5,FPR5,TPR5]=hyperRoc(rGLRT,t);
plot(FPR5,TPR5,'>-')

[AUC6,FPR6,TPR6]=hyperRoc(rOSP,t);
plot(FPR6,TPR6,'<-')

[AUC7,FPR7,TPR7]=hyperRoc(rAMSD,t);
plot(FPR7,TPR7,'.-')


arg=[AUC1 ,AUC2 ,AUC3 ,AUC4 ,AUC5 ,AUC6 ,AUC7 ] ;
xlabel('FPR')
ylabel('TPR')
legend(num2str(arg(1).','CEM   %d '),num2str(arg(2).','ACE   %d '),num2str(arg(3).','SACE   %d '),num2str(arg(4).','MF   %d '),num2str(arg(5).','GLRT   %d '),num2str(arg(6).','OSP   %d '),num2str(arg(7).','AMSD   %d ') ,'Location', 'best');
title(sprintf('ROC curve '), 'Interpreter', 'Latex');


hold off
% load('data1.mat')
% sig=M(280,800,:);
% sig=reshape(sig,[1,126]);
% plot(sig')

